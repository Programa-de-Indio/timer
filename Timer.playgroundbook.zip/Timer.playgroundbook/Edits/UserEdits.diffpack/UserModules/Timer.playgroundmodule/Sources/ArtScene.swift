import SpriteKit

public class ArtScene: SKScene{
    var renderTime: TimeInterval = 0.0
    var changeTime: TimeInterval = 1
    var seconds: Int = 0
    var minutes: Int = 0
    var label:SKLabelNode = SKLabelNode()
    
    override public func didMove(to view: SKView) {
        self.backgroundColor = #colorLiteral(red: 0.23921568627450981, green: 0.6745098039215687, blue: 0.9686274509803922, alpha: 1.0)
        label.text = "00 : 00"
        self.addChild(label)
    }
    
    override public func didChangeSize(_ oldSize: CGSize) {
        label.position.x = self.size.width/2
        label.position.y = self.size.height/2
    }
    
    override public func update(_ currentTime: TimeInterval) {
        if currentTime > renderTime{
            if renderTime > 0{
                seconds += 1
                if seconds == 60 {
                    seconds = 0
                    minutes += 1
                }
                let secondsText = (seconds < 10) ? "0\(seconds)" : "\(seconds)"
                let minutesText = (minutes < 10) ? "0\(minutes)" : "\(minutes)"
                label.text = "\(minutesText) : \(secondsText)"
            }
            renderTime = currentTime + changeTime
        }
    }
}
