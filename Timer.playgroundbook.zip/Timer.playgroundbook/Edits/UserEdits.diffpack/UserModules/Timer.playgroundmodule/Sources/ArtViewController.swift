import UIKit
import SpriteKit

public class ArtViewController: UIViewController{
    override public func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    func setup(){
        let view = SKView()
        let scene = ArtScene()
        scene.scaleMode = .resizeFill
        view.presentScene(scene)
        self.view = view
    }
}
